CREATE TABLE IF NOT EXISTS products (
  id SERIAL PRIMARY KEY, slug TEXT UNIQUE NOT NULL, name TEXT NOT NULL, description TEXT DEFAULT '',
  price_cents INT NOT NULL CHECK (price_cents >= 0), promo_price_cents INT CHECK (promo_price_cents >= 0),
  featured BOOLEAN DEFAULT false, is_launch BOOLEAN DEFAULT false, active BOOLEAN DEFAULT true,
  sold_count INT DEFAULT 0, created_at TIMESTAMPTZ DEFAULT now());
CREATE TABLE IF NOT EXISTS product_images (
  id SERIAL PRIMARY KEY, product_id INT REFERENCES products(id) ON DELETE CASCADE, url TEXT NOT NULL, position INT DEFAULT 0);
CREATE TABLE IF NOT EXISTS product_sizes (
  id SERIAL PRIMARY KEY, product_id INT REFERENCES products(id) ON DELETE CASCADE, size TEXT NOT NULL,
  stock INT NOT NULL DEFAULT 0 CHECK (stock >= 0), UNIQUE (product_id, size));
CREATE TABLE IF NOT EXISTS orders (
  id SERIAL PRIMARY KEY, code TEXT UNIQUE NOT NULL, customer_name TEXT NOT NULL, phone TEXT NOT NULL,
  street TEXT NOT NULL, number TEXT NOT NULL, district TEXT NOT NULL, complement TEXT, city TEXT NOT NULL,
  subtotal_cents INT NOT NULL, shipping_cents INT NOT NULL, total_cents INT NOT NULL,
  payment_method TEXT DEFAULT 'pix', payment_status TEXT DEFAULT 'pending', payment_ref TEXT,
  status TEXT DEFAULT 'AGUARDANDO_PAGAMENTO', created_at TIMESTAMPTZ DEFAULT now());
CREATE TABLE IF NOT EXISTS order_items (
  id SERIAL PRIMARY KEY, order_id INT REFERENCES orders(id) ON DELETE CASCADE, product_id INT REFERENCES products(id),
  product_name TEXT NOT NULL, size TEXT NOT NULL, quantity INT NOT NULL CHECK (quantity > 0), unit_price_cents INT NOT NULL);
CREATE TABLE IF NOT EXISTS reviews (
  id SERIAL PRIMARY KEY, product_id INT REFERENCES products(id) ON DELETE CASCADE, order_code TEXT, author TEXT NOT NULL,
  rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5), comment TEXT, status TEXT DEFAULT 'pending', created_at TIMESTAMPTZ DEFAULT now());
CREATE TABLE IF NOT EXISTS admins (
  id SERIAL PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
INSERT INTO settings(key,value) VALUES
 ('store_name','NexoWear'),('whatsapp',''),('instagram',''),
 ('delivery_cities','São Luís'),('shipping_cents','0'),('delivery_eta','A combinar'),
 ('launch_at',''),('about_text','A NexoWear nasceu com o propósito de conectar pessoas ao próprio estilo. Mais do que vestir, queremos oferecer uma experiência personalizada, entendendo cada cliente e ajudando a encontrar peças que realmente representem sua identidade.')
ON CONFLICT DO NOTHING;
INSERT INTO products(slug,name,description,price_cents,featured) VALUES
 ('nexo-essential-black','Nexo Essential Black','Produto de demonstração.',8990,true),
 ('nexo-essential-white','Nexo Essential White','Produto de demonstração.',8990,true),
 ('nexo-oversized-black','Nexo Oversized Black','Produto de demonstração.',10990,true),
 ('nexo-oversized-white','Nexo Oversized White','Produto de demonstração.',10990,true)
ON CONFLICT DO NOTHING;
-- estoque inicial de demonstração
INSERT INTO product_sizes(product_id,size,stock) SELECT p.id,s,5 FROM products p, unnest(ARRAY['PP','P','M','G','GG','XG']) s ON CONFLICT DO NOTHING;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS pix_code TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS pix_qr TEXT;
