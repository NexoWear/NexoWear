import pg from 'pg'; import fs from 'fs';
const c = new pg.Client({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_URL?.includes('localhost') ? false : { rejectUnauthorized: false } });
await c.connect(); await c.query(fs.readFileSync(new URL('./schema.sql', import.meta.url), 'utf8')); await c.end(); console.log('Banco criado.');
