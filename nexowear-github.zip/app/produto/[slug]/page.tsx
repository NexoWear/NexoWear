import { notFound } from 'next/navigation';
import { pool, brl } from '@/lib/db';
import AddToCart from '@/components/AddToCart';
import FavButton from '@/components/FavButton';
import ReviewForm from '@/components/ReviewForm';
import type { Metadata } from 'next';
export const dynamic = 'force-dynamic';
export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params; const { rows: [p] } = await pool.query('SELECT name,description FROM products WHERE slug=$1 AND active', [slug]);
  return p ? { title: `${p.name} | NexoWear`, description: p.description || `${p.name} - camiseta NexoWear.` } : {};
}
export default async function Produto({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const { rows: [p] } = await pool.query('SELECT * FROM products WHERE slug=$1 AND active', [slug]);
  if (!p) notFound();
  const [{ rows: imgs }, { rows: sizes }, { rows: revs }] = await Promise.all([
    pool.query('SELECT url FROM product_images WHERE product_id=$1 ORDER BY position', [p.id]),
    pool.query(`SELECT size,stock FROM product_sizes WHERE product_id=$1 ORDER BY array_position(ARRAY['PP','P','M','G','GG','XG'],size), size`, [p.id]),
    pool.query(`SELECT author,rating,comment FROM reviews WHERE product_id=$1 AND status='approved' ORDER BY created_at DESC LIMIT 30`, [p.id])]);
  const avg = revs.length ? (revs.reduce((a: number, r: { rating: number }) => a + r.rating, 0) / revs.length).toFixed(1) : null;
  const price = p.promo_price_cents ?? p.price_cents;
  return (<section className="sec"><div className="wrap" style={{ display: 'grid', gap: 32, gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,320px),1fr))' }}>
    <div style={{ display: 'grid', gap: 12 }}>{imgs.length ? imgs.map((i: { url: string }) => <img key={i.url} src={i.url} alt={p.name} loading="lazy" style={{ width: '100%' }} />)
      : <div className="card"><div className="ph">Imagem do produto (placeholder)</div></div>}</div>
    <div><h1 style={{ fontSize: 'clamp(2rem,6vw,3.5rem)' }}>{p.name}</h1>
      <p style={{ fontSize: 24, margin: '16px 0' }}>{p.promo_price_cents != null && <s className="sold" style={{ marginRight: 10 }}>{brl(p.price_cents)}</s>}{brl(price)}</p>
      <p className="sold" style={{ fontSize: 16, maxWidth: '60ch' }}>{p.description}</p>
      <AddToCart p={{ id: p.id, slug: p.slug, name: p.name, price }} sizes={sizes} />
      <div style={{ marginTop: 8 }}><FavButton slug={p.slug} /></div></div></div>
    <div className="wrap" style={{ marginTop: 56 }}><h2 style={{ fontSize: '2rem' }}>Avaliações{avg && ` · ★ ${avg}`}</h2>
      {revs.length ? revs.map((r: { author: string; rating: number; comment: string }, k: number) => <div key={k} style={{ padding: '14px 0', borderBottom: '1px solid #2a2a2a' }}><strong>{r.author}</strong> {'★'.repeat(r.rating)}<p className="sold" style={{ fontSize: 15 }}>{r.comment}</p></div>) : <p className="sold" style={{ marginTop: 12 }}>Este produto ainda não tem avaliações.</p>}
      <ReviewForm productId={p.id} /></div></section>);
}
