'use client';
import { use, useEffect, useState } from 'react';
const L: Record<string, string> = { AGUARDANDO_PAGAMENTO: 'Aguardando pagamento', PAGAMENTO_APROVADO: 'Pagamento aprovado', EM_PREPARACAO: 'Em preparação', SAIU_PARA_ENTREGA: 'Saiu para entrega', ENTREGUE: 'Entregue', CANCELADO: 'Cancelado' };
export default function PedidoRecebido({ params }: { params: Promise<{ code: string }> }) {
  const { code } = use(params); const [status, setStatus] = useState(''); const [url, setUrl] = useState(''); const [err, setErr] = useState('');
  useEffect(() => {
    fetch(`/api/orders/${code}`).then(r => r.ok ? r.json() : Promise.reject()).then(o => setStatus(o.status)).catch(() => setErr('Pedido não encontrado.'));
    let u = ''; try { u = sessionStorage.getItem(`nexowear_wa_${code}`) || ''; } catch {}
    if (u) { setUrl(u); try { if (!sessionStorage.getItem(`nexowear_wa_open_${code}`)) { sessionStorage.setItem(`nexowear_wa_open_${code}`, '1'); location.href = u; } } catch {} }
    else fetch('/api/store').then(r => r.json()).then(s => { const d = String(s.whatsapp || '').replace(/\D/g, ''); if (d) setUrl(`https://wa.me/${d.length <= 11 ? '55' + d : d}?text=${encodeURIComponent(`Olá, NexoWear! Meu pedido é o ${code}.`)}`); }).catch(() => {});
  }, [code]);
  if (err) return <p role="alert" className="wrap sec">{err}</p>;
  return (<section className="sec"><div className="wrap" style={{ maxWidth: 560 }}>
    <h2>Pedido realizado com sucesso!</h2>
    <p style={{ margin: '16px 0' }}>Número do pedido: <strong>{code}</strong></p>
    <p className="sold" style={{ marginBottom: 20 }}>Para concluir, envie o pedido pelo WhatsApp da loja. Lá combinamos o pagamento e a entrega. Guarde o número do pedido para acompanhar.</p>
    {url && <a className="btn" href={url}>Abrir WhatsApp da loja</a>}
    <p role="status" className="sold" style={{ marginTop: 20 }}>Situação atual: {status ? (L[status] ?? status) : 'consultando…'}</p></div></section>);
}
