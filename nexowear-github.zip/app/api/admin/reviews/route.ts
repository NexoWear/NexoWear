import { pool } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
export const dynamic = 'force-dynamic';
export async function GET() { const d = await requireAdmin(); if (d) return d;
  const { rows } = await pool.query('SELECT r.id,r.rating,r.comment,r.author,r.status,p.name AS product FROM reviews r JOIN products p ON p.id=r.product_id ORDER BY r.created_at DESC LIMIT 200'); return Response.json(rows); }
export async function PATCH(req: Request) { const d = await requireAdmin(); if (d) return d;
  const { id, status } = await req.json().catch(() => ({})); if (!['approved', 'hidden', 'pending'].includes(status)) return Response.json({ error: 'Status inválido.' }, { status: 400 });
  await pool.query('UPDATE reviews SET status=$1 WHERE id=$2', [status, id]); return Response.json({ ok: true }); }
export async function DELETE(req: Request) { const d = await requireAdmin(); if (d) return d;
  await pool.query('DELETE FROM reviews WHERE id=$1', [new URL(req.url).searchParams.get('id')]); return Response.json({ ok: true }); }
