import { pool } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
import { getSettings } from '@/lib/settings';
export const dynamic = 'force-dynamic';
const KEYS = ['store_name', 'phone', 'whatsapp', 'instagram', 'delivery_cities', 'shipping_cents', 'delivery_eta', 'pickup_enabled', 'launch_at', 'about_text'];
export async function GET() { const d = await requireAdmin(); if (d) return d; return Response.json(await getSettings()); }
export async function PUT(req: Request) {
  const d = await requireAdmin(); if (d) return d;
  const b = await req.json().catch(() => ({}));
  if (b.shipping_cents !== undefined && !/^\d+$/.test(String(b.shipping_cents))) return Response.json({ error: 'Taxa de entrega inválida.' }, { status: 400 });
  if (b.delivery_cities !== undefined && !String(b.delivery_cities).split(',').map((x: string) => x.trim()).filter(Boolean).length) return Response.json({ error: 'Informe pelo menos uma cidade atendida.' }, { status: 400 });
  for (const k of KEYS) if (typeof b[k] === 'string') await pool.query('INSERT INTO settings(key,value) VALUES($1,$2) ON CONFLICT (key) DO UPDATE SET value=$2', [k, b[k]]);
  return Response.json({ ok: true });
}
