import { pool } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
export const dynamic = 'force-dynamic';
export async function GET() {
  const d = await requireAdmin(); if (d) return d;
  const paid = `('PAGAMENTO_APROVADO','EM_PREPARACAO','SAIU_PARA_ENTREGA','ENTREGUE')`;
  const [{ rows: [t] }, { rows: by }, { rows: top }, { rows: [pr] }, { rows: low }] = await Promise.all([
    pool.query(`SELECT COUNT(*)::int AS orders, COALESCE(SUM(total_cents) FILTER (WHERE status IN ${paid}),0)::int AS revenue, COUNT(*) FILTER (WHERE status IN ${paid})::int AS sales FROM orders`),
    pool.query('SELECT status, COUNT(*)::int AS n FROM orders GROUP BY status'),
    pool.query(`SELECT i.product_name AS name, SUM(i.quantity)::int AS qty FROM order_items i JOIN orders o ON o.id=i.order_id WHERE o.status IN ${paid} GROUP BY 1 ORDER BY 2 DESC LIMIT 5`),
    pool.query('SELECT COUNT(*)::int AS n, (SELECT COALESCE(SUM(stock),0)::int FROM product_sizes) AS stock FROM products'),
    pool.query(`SELECT p.name, s.size, s.stock FROM product_sizes s JOIN products p ON p.id=s.product_id WHERE s.stock<=2 ORDER BY s.stock LIMIT 10`)]);
  return Response.json({ ...t, byStatus: by, top, products: pr.n, stock: pr.stock, low });
}
