import { pool } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
import { cancelAndRestock, cancelPaidAndRestock, expireStaleOrders } from '@/lib/orders';
export const dynamic = 'force-dynamic';
const ST = ['AGUARDANDO_PAGAMENTO', 'PAGAMENTO_APROVADO', 'EM_PREPARACAO', 'SAIU_PARA_ENTREGA', 'ENTREGUE', 'CANCELADO'];
export async function GET() {
  const d = await requireAdmin(); if (d) return d;
  await expireStaleOrders().catch(() => {});
  const { rows } = await pool.query(`SELECT o.*, COALESCE((SELECT json_agg(json_build_object('name',product_name,'size',size,'qty',quantity,'price',unit_price_cents)) FROM order_items WHERE order_id=o.id),'[]') AS items
    FROM orders o ORDER BY o.id DESC LIMIT 200`);
  return Response.json(rows.map(({ pix_qr, pix_code, ...r }) => r));
}
export async function PATCH(req: Request) {
  const d = await requireAdmin(); if (d) return d;
  const { id, status, confirmRefund } = await req.json().catch(() => ({}));
  if (!ST.includes(status)) return Response.json({ error: 'Status inválido.' }, { status: 400 });
  const { rows: [o] } = await pool.query('SELECT status FROM orders WHERE id=$1', [id]);
  if (!o) return Response.json({ error: 'Pedido não encontrado.' }, { status: 404 });
  if (o.status === 'CANCELADO' && status !== 'CANCELADO') return Response.json({ error: 'Pedido cancelado não pode ser reaberto. Peça um novo pedido.' }, { status: 400 });
  if (status === 'CANCELADO') {
    if (o.status === 'CANCELADO') return Response.json({ ok: true });
    if (['SAIU_PARA_ENTREGA', 'ENTREGUE'].includes(o.status))
      return Response.json({ error: 'Pedido já despachado ou entregue não pode ser cancelado aqui.' }, { status: 400 });
    if (o.status !== 'AGUARDANDO_PAGAMENTO') {
      if (confirmRefund !== true) return Response.json({ error: 'Pedido pago: confirme que o valor foi devolvido ao cliente para cancelar.' }, { status: 409 });
      const done = await cancelPaidAndRestock(Number(id));
      if (!done) return Response.json({ error: 'O pedido mudou de status e não pode mais ser cancelado.' }, { status: 409 });
      return Response.json({ ok: true });
    }
    const changed = await cancelAndRestock(Number(id));
    if (!changed) return Response.json({ error: 'O pedido mudou de status e não pode mais ser cancelado.' }, { status: 409 });
    return Response.json({ ok: true });
  }
  await pool.query('UPDATE orders SET status=$1 WHERE id=$2', [status, id]);
  return Response.json({ ok: true });
}
