import { randomUUID } from 'crypto';
import { requireAdmin } from '@/lib/auth';
const EXT: Record<string, string> = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' };
export async function POST(req: Request) {
  const d = await requireAdmin(); if (d) return d;
  const { SUPABASE_URL: url, SUPABASE_SERVICE_KEY: key, SUPABASE_BUCKET: bucket = 'products' } = process.env;
  if (!url || !key) return Response.json({ error: 'Armazenamento de imagens não configurado (SUPABASE_URL e SUPABASE_SERVICE_KEY).' }, { status: 503 });
  const file = (await req.formData()).get('file');
  if (!(file instanceof File) || !EXT[file.type]) return Response.json({ error: 'Envie uma imagem JPG, PNG ou WEBP.' }, { status: 400 });
  if (file.size > 4 * 1024 * 1024) return Response.json({ error: 'A imagem deve ter no máximo 4 MB.' }, { status: 400 });
  const path = `${randomUUID()}.${EXT[file.type]}`;
  const r = await fetch(`${url}/storage/v1/object/${bucket}/${path}`, { method: 'POST', headers: { Authorization: `Bearer ${key}`, 'Content-Type': file.type }, body: Buffer.from(await file.arrayBuffer()) });
  if (!r.ok) return Response.json({ error: 'Falha ao enviar a imagem.' }, { status: 502 });
  return Response.json({ url: `${url}/storage/v1/object/public/${bucket}/${path}` });
}
