import { pool } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
export const dynamic = 'force-dynamic';
const slugify = (s: string) => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
export async function GET() {
  const d = await requireAdmin(); if (d) return d;
  const { rows } = await pool.query(`SELECT p.*,
    COALESCE((SELECT json_agg(url ORDER BY position) FROM product_images WHERE product_id=p.id),'[]') AS images,
    COALESCE((SELECT json_agg(json_build_object('size',size,'stock',stock) ORDER BY id) FROM product_sizes WHERE product_id=p.id),'[]') AS sizes
    FROM products p ORDER BY p.created_at DESC`);
  return Response.json(rows);
}
export async function POST(req: Request) {
  const d = await requireAdmin(); if (d) return d;
  const b = await req.json().catch(() => null);
  if (!b?.name?.trim()) return Response.json({ error: 'Informe o nome do produto.' }, { status: 400 });
  if (String(b.price ?? '').trim() === '') return Response.json({ error: 'Informe o preço do produto.' }, { status: 400 });
  const priceNumber = Number(String(b.price).replace(',', '.'));
  if (!Number.isFinite(priceNumber) || priceNumber <= 0) return Response.json({ error: 'O preço deve ser um número maior que zero.' }, { status: 400 });
  const cents = Math.round(priceNumber * 100);
  const promoNumber = b.promo === '' || b.promo == null ? null : Number(String(b.promo).replace(',', '.'));
  if (promoNumber != null && (!Number.isFinite(promoNumber) || promoNumber < 0)) return Response.json({ error: 'Preço promocional inválido.' }, { status: 400 });
  const promo = promoNumber == null ? null : Math.round(promoNumber * 100);
  if (promo != null && promo >= cents) return Response.json({ error: 'O preço promocional deve ser menor que o preço.' }, { status: 400 });
  const c = await pool.connect();
  try {
    await c.query('BEGIN'); let id = b.id;
    if (id) await c.query('UPDATE products SET name=$1,description=$2,price_cents=$3,promo_price_cents=$4,featured=$5,is_launch=$6,active=$7 WHERE id=$8',
      [b.name.trim(), b.description ?? '', cents, promo, !!b.featured, !!b.is_launch, !!b.active, id]);
    else { const r = await c.query('INSERT INTO products(slug,name,description,price_cents,promo_price_cents,featured,is_launch,active) VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id',
      [`${slugify(b.name)}-${Date.now().toString(36)}`, b.name.trim(), b.description ?? '', cents, promo, !!b.featured, !!b.is_launch, b.active !== false]); id = r.rows[0].id; }
    await c.query('DELETE FROM product_images WHERE product_id=$1', [id]);
    for (const [k, u] of (b.images as string[] ?? []).filter(Boolean).entries()) await c.query('INSERT INTO product_images(product_id,url,position) VALUES($1,$2,$3)', [id, u, k]);
    const sizes = (b.sizes as { size: string; stock: number }[] ?? []).filter(s => s.size?.trim());
    await c.query('DELETE FROM product_sizes WHERE product_id=$1 AND size<>ALL($2::text[])', [id, sizes.map(s => s.size.trim().toUpperCase())]);
    for (const s of sizes) await c.query('INSERT INTO product_sizes(product_id,size,stock) VALUES($1,$2,$3) ON CONFLICT (product_id,size) DO UPDATE SET stock=$3', [id, s.size.trim().toUpperCase(), Math.max(0, Math.floor(+s.stock || 0))]);
    await c.query('COMMIT'); return Response.json({ id });
  } catch { await c.query('ROLLBACK'); return Response.json({ error: 'Erro ao salvar o produto.' }, { status: 500 }); } finally { c.release(); }
}
export async function DELETE(req: Request) {
  const d = await requireAdmin(); if (d) return d;
  const id = new URL(req.url).searchParams.get('id');
  try { await pool.query('DELETE FROM products WHERE id=$1', [id]); return Response.json({ ok: true }); }
  catch { await pool.query('UPDATE products SET active=false WHERE id=$1', [id]); return Response.json({ ok: true, note: 'Produto com pedidos foi apenas desativado.' }); }
}
