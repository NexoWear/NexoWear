import { pool } from '@/lib/db';
import { checkPassword, startSession } from '@/lib/auth';
export async function POST(req: Request) {
  const { email, password } = await req.json().catch(() => ({}));
  const { rows: [a] } = await pool.query('SELECT id,password_hash FROM admins WHERE email=$1', [String(email ?? '').toLowerCase()]);
  const ok = a && checkPassword(String(password ?? ''), a.password_hash);
  if (!ok) { await new Promise(r => setTimeout(r, 800)); return Response.json({ error: 'E-mail ou senha incorretos.' }, { status: 401 }); }
  await startSession(a.id); return Response.json({ ok: true });
}
