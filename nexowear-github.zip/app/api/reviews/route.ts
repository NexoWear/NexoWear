import { pool } from '@/lib/db';
const bad = (error: string, status = 400) => Response.json({ error }, { status });
export async function POST(req: Request) {
  const b = await req.json().catch(() => null); const rating = Math.floor(Number(b?.rating));
  if (!b || !(rating >= 1 && rating <= 5)) return bad('Escolha de 1 a 5 estrelas.');
  const code = String(b.orderCode ?? '').trim().toUpperCase();
  const { rows: [o] } = await pool.query(`SELECT o.customer_name FROM orders o JOIN order_items i ON i.order_id=o.id WHERE o.code=$1 AND i.product_id=$2 AND o.status='ENTREGUE' LIMIT 1`, [code, b.productId]);
  if (!o) return bad('Só é possível avaliar com o número de um pedido entregue que contenha este produto.', 403);
  const dup = await pool.query('SELECT 1 FROM reviews WHERE order_code=$1 AND product_id=$2', [code, b.productId]);
  if (dup.rowCount) return bad('Este pedido já avaliou este produto.', 409);
  await pool.query('INSERT INTO reviews(product_id,order_code,author,rating,comment) VALUES($1,$2,$3,$4,$5)', [b.productId, code, String(o.customer_name).split(' ')[0], rating, String(b.comment ?? '').slice(0, 1000)]);
  return Response.json({ ok: true });
}
