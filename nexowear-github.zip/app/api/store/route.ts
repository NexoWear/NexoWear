import { getSettings } from '@/lib/settings';
export const dynamic = 'force-dynamic';
export async function GET() {
  const s = await getSettings();
  return Response.json({ store_name: s.store_name || 'NexoWear', delivery_cities: s.delivery_cities || '', shipping_cents: s.shipping_cents || '0', delivery_eta: s.delivery_eta || 'A combinar', whatsapp: s.whatsapp || '' }, { headers: { 'Cache-Control': 'public, max-age=60, s-maxage=60' } });
}
