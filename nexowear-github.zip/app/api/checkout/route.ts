import { randomBytes } from 'crypto';
import { pool } from '@/lib/db';
import { getSettings } from '@/lib/settings';
import { expireStaleOrders } from '@/lib/orders';
import { waNumber, whatsappUrl } from '@/lib/whatsapp';
const bad = (error: string, status = 400) => Response.json({ error }, { status });
const norm = (s: string) => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim().toLowerCase();
const makeOrderCode = () => 'NXW-' + randomBytes(5).toString('hex').toUpperCase();
export async function POST(req: Request) {
  const b = await req.json().catch(() => null);
  if (!b || !Array.isArray(b.items) || !b.items.length) return bad('Carrinho vazio.');
  for (const k of ['name', 'phone', 'street', 'number', 'district', 'city']) if (!String(b[k] ?? '').trim()) return bad('Preencha todos os campos obrigatórios.');
  const cfg = await getSettings();
  const cities = (cfg.delivery_cities || '').split(',').map(norm).filter(Boolean);
  if (!cities.includes(norm(String(b.city)))) return bad(`Atualmente realizamos entregas somente em ${(cfg.delivery_cities || '').split(',').map(x => x.trim()).join(', ')}.`);
  const wa = waNumber(cfg.whatsapp || '');
  if (!wa) return bad('O WhatsApp da loja ainda não foi configurado. Tente novamente mais tarde.', 503);
  await expireStaleOrders().catch(() => {});
  const c = await pool.connect();
  const lines: { name: string; size: string; qty: number; price: number }[] = []; const pids: number[] = [];
  let code = '', sub = 0, ship = 0, total = 0;
  try {
    await c.query('BEGIN');
    for (const it of b.items) {
      const qty = Math.floor(Number(it.qty)); if (!(qty > 0) || qty > 20) throw new Error('Quantidade inválida.');
      const { rows: [p] } = await c.query('SELECT id,name,price_cents,promo_price_cents FROM products WHERE id=$1 AND active', [it.productId]);
      if (!p) throw new Error('Um produto do carrinho não está mais disponível.');
      const u = await c.query('UPDATE product_sizes SET stock=stock-$1 WHERE product_id=$2 AND size=$3 AND stock>=$1', [qty, p.id, String(it.size)]);
      if (!u.rowCount) throw new Error(`Sem estoque de ${p.name} no tamanho ${it.size}.`);
      const price = p.promo_price_cents ?? p.price_cents; sub += price * qty; lines.push({ name: p.name, size: String(it.size), qty, price });
      pids.push(p.id);
    }
    ship = parseInt(cfg.shipping_cents) || 0; total = sub + ship; code = makeOrderCode();
    const { rows: [o] } = await c.query(`INSERT INTO orders(code,customer_name,phone,street,number,district,complement,city,subtotal_cents,total_cents,shipping_cents,payment_method)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,'whatsapp') RETURNING id`,
      [code, String(b.name).trim(), String(b.phone).trim(), String(b.street).trim(), String(b.number).trim(), String(b.district).trim(), String(b.complement ?? '').trim() || null, String(b.city).trim(), sub, total, ship]);
    for (const [k, l] of lines.entries()) await c.query('INSERT INTO order_items(order_id,product_id,product_name,size,quantity,unit_price_cents) VALUES($1,$2,$3,$4,$5,$6)', [o.id, pids[k], l.name, l.size, l.qty, l.price]);
    await c.query('COMMIT');
  } catch (e) { await c.query('ROLLBACK'); c.release(); return bad(e instanceof Error ? e.message : 'Erro ao criar o pedido.'); }
  c.release();
  return Response.json({ code, whatsappUrl: whatsappUrl(wa, { code, name: String(b.name).trim(), phone: String(b.phone).trim(), street: String(b.street).trim(), number: String(b.number).trim(),
    district: String(b.district).trim(), complement: String(b.complement ?? '').trim() || null, city: String(b.city).trim(), subtotal: sub, shipping: ship, total, lines }) });
}
