import { pool } from '@/lib/db';
export const dynamic = 'force-dynamic';
export async function GET(_: Request, { params }: { params: Promise<{ code: string }> }) {
  const { code } = await params;
  const { rows: [o] } = await pool.query('SELECT code,status,total_cents,created_at FROM orders WHERE code=$1', [code.trim().toUpperCase()]);
  if (!o) return Response.json({ error: 'Pedido não encontrado.' }, { status: 404 });
  return Response.json(o);
}
