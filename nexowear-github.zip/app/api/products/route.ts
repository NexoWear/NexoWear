import { listProducts } from '@/lib/db';
export const dynamic = 'force-dynamic';
export async function GET(req: Request) {
  const q = new URL(req.url).searchParams.get('q') ?? undefined;
  try { return Response.json(await listProducts({ q })); }
  catch { return Response.json({ error: 'Não foi possível carregar os produtos.' }, { status: 500 }); }
}
