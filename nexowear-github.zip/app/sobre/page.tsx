import { getSettings } from '@/lib/settings';
export const dynamic = 'force-dynamic';
export const metadata = { title: 'Sobre nós | NexoWear' };
export default async function Sobre() {
  const c = await getSettings().catch(() => ({} as Record<string, string>));
  return <section className="sec"><div className="wrap" style={{ maxWidth: 720 }}><h1 style={{ fontSize: 'clamp(2.5rem,8vw,5rem)' }}>Sobre nós</h1><p style={{ marginTop: 24, fontSize: 20, lineHeight: 1.6, whiteSpace: 'pre-line' }}>{c.about_text}</p></div></section>;
}
