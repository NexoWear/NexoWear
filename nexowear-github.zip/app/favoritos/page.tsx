'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { useFavs } from '@/lib/favorites';
import { brl } from '@/lib/format';
type P = { slug: string; name: string; price_cents: number; promo_price_cents: number | null; image: string | null };
export default function Favoritos() {
  const favs = useFavs(); const [all, setAll] = useState<P[] | null>(null); const [err, setErr] = useState(false);
  useEffect(() => { fetch('/api/products').then(r => r.json()).then(d => Array.isArray(d) ? setAll(d) : setErr(true)).catch(() => setErr(true)); }, []);
  const list = (all ?? []).filter(p => favs.includes(p.slug));
  return (<section className="sec"><div className="wrap"><h2>Favoritos</h2>
    {err ? <p role="alert" className="sold">Erro ao carregar os favoritos.</p> : all === null ? <p className="sold">Carregando…</p>
    : !list.length ? <p className="sold" style={{ margin: '16px 0 24px' }}>Você ainda não favoritou nenhuma camiseta. <Link href="/loja" style={{ textDecoration: 'underline' }}>Ver loja</Link></p>
    : <div className="grid">{list.map(p => <article className="card" key={p.slug}><Link href={`/produto/${p.slug}`}><div className="ph">{p.image ? <img src={p.image} alt={p.name} loading="lazy" /> : <span>Imagem do produto (placeholder)</span>}</div><h3>{p.name}</h3><div className="pr">{brl(p.promo_price_cents ?? p.price_cents)}</div></Link></article>)}</div>}</div></section>);
}
