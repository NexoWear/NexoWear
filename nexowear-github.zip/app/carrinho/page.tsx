'use client';
import Link from 'next/link';
import { useCart, writeCart } from '@/lib/cart';
import { brl } from '@/lib/format';
export default function Carrinho() {
  const { items, ready } = useCart();
  const total = items.reduce((s, i) => s + i.price * i.qty, 0);
  const upd = (idx: number, qty: number) => writeCart(items.map((x, k) => k === idx ? { ...x, qty: Math.max(1, qty) } : x));
  if (!ready) return <p className="wrap sec sold">Carregando carrinho…</p>;
  if (!items.length) return <section className="sec"><div className="wrap"><h2>Carrinho</h2><p className="sold" style={{ margin: '16px 0 24px' }}>Seu carrinho está vazio.</p><Link className="btn" href="/loja">Ver camisetas</Link></div></section>;
  return (<section className="sec"><div className="wrap"><h2>Carrinho</h2>
    <ul style={{ listStyle: 'none', margin: '24px 0' }}>{items.map((i, k) => <li key={k} style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', gap: 12, padding: '16px 0', borderBottom: '1px solid #2a2a2a' }}>
      <div><strong>{i.name}</strong><div className="sold">Tamanho {i.size} · {brl(i.price)}</div></div>
      <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
        <button aria-label="Diminuir" onClick={() => upd(k, i.qty - 1)} className="btn" style={{ padding: '8px 14px' }}>−</button><span>{i.qty}</span>
        <button aria-label="Aumentar" onClick={() => upd(k, i.qty + 1)} className="btn" style={{ padding: '8px 14px' }}>+</button>
        <strong style={{ minWidth: 90, textAlign: 'right' }}>{brl(i.price * i.qty)}</strong>
        <button onClick={() => writeCart(items.filter((_, j) => j !== k))} className="sold" style={{ background: 'none', border: 0, color: '#9a9a9a', cursor: 'pointer' }}>Remover</button></div></li>)}</ul>
    <p style={{ fontSize: 24, marginBottom: 24 }}>Total: <strong>{brl(total)}</strong></p>
    <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}><Link className="btn" href="/checkout">Ir para pagamento</Link><Link className="btn" style={{ background: '#000', color: '#fff' }} href="/loja">Continuar comprando</Link></div></div></section>);
}
