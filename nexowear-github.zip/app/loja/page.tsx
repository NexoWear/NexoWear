import { listProducts } from '@/lib/db';
import ProductCard from '@/components/ProductCard';
export const dynamic = 'force-dynamic';
export const metadata = { title: 'Loja | NexoWear', description: 'Camisetas NexoWear. Filtre por tamanho, preço e avaliação.' };
const F = { background: '#000', color: '#fff', border: '1px solid #666', padding: 12, fontSize: 15, width: '100%' } as const;
export default async function Loja({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const s = await searchParams;
  const products = await listProducts({ q: s.q, size: s.size || undefined, inStock: s.disp === '1', maxPrice: s.max ? Math.round(+s.max * 100) : undefined,
    minRating: s.nota ? +s.nota : undefined, sort: s.ordem }).catch(() => null);
  return (<section className="sec"><div className="wrap"><h2>Loja</h2>
    <form action="/loja" style={{ display: 'grid', gap: 10, gridTemplateColumns: 'repeat(auto-fit,minmax(150px,1fr))', margin: '20px 0' }}>
      <input style={F} name="q" defaultValue={s.q} placeholder="Buscar camiseta" aria-label="Buscar produto" />
      <select style={F} name="size" defaultValue={s.size ?? ''} aria-label="Tamanho"><option value="">Todos os tamanhos</option>{['PP', 'P', 'M', 'G', 'GG', 'XG'].map(x => <option key={x}>{x}</option>)}</select>
      <input style={F} name="max" type="number" min={0} defaultValue={s.max} placeholder="Preço máximo (R$)" aria-label="Preço máximo" />
      <select style={F} name="nota" defaultValue={s.nota ?? ''} aria-label="Avaliação"><option value="">Qualquer avaliação</option><option value="4">4★ ou mais</option><option value="3">3★ ou mais</option></select>
      <select style={F} name="ordem" defaultValue={s.ordem ?? ''} aria-label="Ordenar"><option value="">Novidades</option><option value="vendidos">Mais vendidos</option><option value="avaliacao">Melhor avaliados</option><option value="menor">Menor preço</option></select>
      <label style={{ display: 'flex', gap: 8, alignItems: 'center' }}><input type="checkbox" name="disp" value="1" defaultChecked={s.disp === '1'} /> Só disponíveis</label>
      <button className="btn">Filtrar</button></form>
    {products === null ? <p role="alert" className="sold">Erro ao carregar produtos.</p>
     : products.length === 0 ? <p className="sold">Nenhuma camiseta encontrada com esses filtros.</p>
     : <div className="grid">{products.map(p => <ProductCard key={p.id} p={p} />)}</div>}</div></section>);
}
