'use client';
import { useState } from 'react';
const L: Record<string, string> = { AGUARDANDO_PAGAMENTO: 'Aguardando pagamento', PAGAMENTO_APROVADO: 'Pagamento aprovado', EM_PREPARACAO: 'Em preparação', SAIU_PARA_ENTREGA: 'Saiu para entrega', ENTREGUE: 'Entregue', CANCELADO: 'Cancelado' };
export default function Acompanhar() {
  const [code, setCode] = useState(''); const [msg, setMsg] = useState('');
  async function go(e: React.FormEvent) { e.preventDefault(); setMsg('Consultando…'); const r = await fetch(`/api/orders/${encodeURIComponent(code.trim())}`); const d = await r.json(); setMsg(r.ok ? `Pedido ${d.code}: ${L[d.status] ?? d.status}` : d.error); }
  return (<section className="sec"><div className="wrap" style={{ maxWidth: 560 }}><h2>Acompanhar pedido</h2>
    <form onSubmit={go} style={{ display: 'grid', gap: 12, margin: '24px 0' }}><input value={code} onChange={e => setCode(e.target.value)} placeholder="NXW-000001" required aria-label="Número do pedido"
      style={{ background: '#000', color: '#fff', border: '1px solid #666', padding: 14 }} /><button className="btn">Consultar</button></form><p role="status">{msg}</p></div></section>);
}
