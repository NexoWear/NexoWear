import './globals.css';
import type { Metadata } from 'next';
import Header from '@/components/Header';

export const metadata: Metadata = {
  title: 'NexoWear | Vista sua identidade.',
  description: 'NexoWear — camisetas, estilo e identidade. Encontre seu estilo e compre online.',
  icons: { icon: '/logo.png' },
  openGraph: { title: 'NexoWear | Vista sua identidade.', description: 'Camisetas NexoWear. Vista sua identidade.', images: ['/logo.png'], locale: 'pt_BR', type: 'website' },
};

export default function Root({ children }: { children: React.ReactNode }) {
  return <html lang="pt-BR"><body><Header /><main>{children}</main><footer className="foot"><div className="wrap"><span>© NexoWear. Todos os direitos reservados.</span><span>Moda • Identidade • Atitude</span></div></footer></body></html>;
}
