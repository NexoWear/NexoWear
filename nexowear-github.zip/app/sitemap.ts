import type { MetadataRoute } from 'next';
import { pool } from '@/lib/db';
export const dynamic = 'force-dynamic';
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = process.env.APP_URL ?? 'http://localhost:3000';
  const { rows } = await pool.query('SELECT slug FROM products WHERE active').catch(() => ({ rows: [] as { slug: string }[] }));
  return [...['', '/loja', '/sobre', '/contato', '/pedido'].map(p => ({ url: base + p })), ...rows.map(r => ({ url: `${base}/produto/${r.slug}` }))];
}
