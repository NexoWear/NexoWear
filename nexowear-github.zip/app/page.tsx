import Link from 'next/link';
import { listProducts } from '@/lib/db';
import Countdown from '@/components/Countdown';
import { getSettings } from '@/lib/settings';
import ProductCard from '@/components/ProductCard';
export const dynamic = 'force-dynamic';

export default async function Home() {
  const products = await listProducts({ featured: true }).catch(() => null);
  const cfg = await getSettings().catch(() => ({} as Record<string, string>));
  return <>
    <section className="hero">
      <div className="wrap">
        <div className="hero-kicker">NexoWear® • Coleção 01</div>
        <h1>Vista sua identidade.</h1>
        <p>Peças pensadas para diferentes estilos, com atendimento personalizado para cada cliente.</p>
        <div className="hero-actions"><Link className="btn" href="/loja">Ver coleção</Link><Link className="btn secondary" href="/sobre">Conheça a NexoWear</Link></div>
      </div>
    </section>

    {cfg.launch_at && <Countdown at={cfg.launch_at} />}

    <section className="sec"><div className="wrap">
      <div className="section-head"><div><p className="hero-kicker">Seleção NexoWear</p><h2>Destaques</h2></div><Link href="/loja" className="sold">Ver todas →</Link></div>
      {products === null ? <p className="sold" style={{marginTop:32}}>Não foi possível carregar os produtos. Tente novamente em instantes.</p>
       : products.length === 0 ? <p className="sold" style={{marginTop:32}}>Nenhum destaque cadastrado ainda.</p>
       : <div className="grid">{products.map(p => <ProductCard key={p.id} p={p} />)}</div>}
    </div></section>

    <section className="sec" style={{borderTop:'1px solid var(--line)'}}><div className="wrap">
      <p className="hero-kicker">Por que NexoWear?</p><h2>Mais que uma camiseta.</h2>
      <div className="feature-list">
        <div className="feature"><strong>Atendimento personalizado</strong><p>A gente entende o que você procura e ajuda a encontrar a peça certa para o seu estilo.</p></div>
        <div className="feature"><strong>Compra simples</strong><p>Escolha sua camiseta, confira o pedido e finalize pelo WhatsApp, direto com a loja.</p></div>
        <div className="feature"><strong>Identidade própria</strong><p>Uma estética limpa, forte e feita para você vestir do seu jeito.</p></div>
      </div>
    </div></section>

    <section className="sec"><div className="wrap" style={{display:'flex',justifyContent:'space-between',alignItems:'end',gap:24,flexWrap:'wrap'}}>
      <div><p className="hero-kicker">NexoWear</p><h2>Encontre seu estilo.</h2></div><Link className="btn" href="/contato">Fale com a gente</Link>
    </div></section>
  </>;
}
