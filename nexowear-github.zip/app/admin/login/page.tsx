'use client';
import { useState } from 'react';
const F = { background: '#000', color: '#fff', border: '1px solid #666', padding: 14, width: '100%', fontSize: 16 } as const;
export default function Login() {
  const [err, setErr] = useState('');
  async function go(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); const f = Object.fromEntries(new FormData(e.currentTarget));
    const r = await fetch('/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(f) });
    if (r.ok) location.href = '/admin'; else setErr((await r.json()).error);
  }
  return (<section className="sec"><div className="wrap" style={{ maxWidth: 420 }}><h2>Admin</h2>
    <form onSubmit={go} style={{ display: 'grid', gap: 12, marginTop: 24 }}><input style={F} name="email" type="email" placeholder="E-mail" required autoComplete="username" />
      <input style={F} name="password" type="password" placeholder="Senha" required autoComplete="current-password" />
      {err && <p role="alert">{err}</p>}<button className="btn">Entrar</button></form></div></section>);
}
