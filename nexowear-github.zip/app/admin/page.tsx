import { redirect } from 'next/navigation';
import { isAdmin } from '@/lib/auth';
import AdminApp from '@/components/AdminApp';
export const dynamic = 'force-dynamic';
export const metadata = { title: 'Admin | NexoWear', robots: { index: false } };
export default async function Admin() { if (!(await isAdmin())) redirect('/admin/login'); return <AdminApp />; }
