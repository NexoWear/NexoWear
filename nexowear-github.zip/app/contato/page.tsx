import { getSettings } from '@/lib/settings';
export const dynamic = 'force-dynamic';
export const metadata = { title: 'Contato | NexoWear' };
export default async function Contato() {
  const c = await getSettings().catch(() => ({} as Record<string, string>));
  const ig = (c.instagram || '').replace('@', '');
  return <section className="sec"><div className="wrap" style={{ maxWidth: 720 }}><h1 style={{ fontSize: 'clamp(2.5rem,8vw,5rem)' }}>Contato</h1>
    <div style={{ display: 'grid', gap: 16, marginTop: 24 }}>
      {c.whatsapp ? <a className="btn" href={`https://wa.me/${c.whatsapp.replace(/\D/g, '')}`}>Falar no WhatsApp</a> : <p className="sold">WhatsApp ainda não configurado.</p>}
      {ig && <a className="btn" style={{ background: '#000', color: '#fff' }} href={`https://instagram.com/${ig}`}>Instagram @{ig}</a>}
      {c.phone && <p>Telefone: {c.phone}</p>}<p className="sold">Entregas em: {c.delivery_cities}. Prazo: {c.delivery_eta}.</p></div></div></section>;
}
