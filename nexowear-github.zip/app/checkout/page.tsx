'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useCart, writeCart } from '@/lib/cart';
import { brl } from '@/lib/format';
const F = { background: '#000', color: '#fff', border: '1px solid #666', padding: 14, width: '100%', fontSize: 16 } as const;
export default function Checkout() {
  const { items, ready } = useCart(); const r = useRouter();
  const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const [city, setCity] = useState(''); const [shipping, setShipping] = useState<number | null>(null);
  useEffect(() => { fetch('/api/store').then(x => x.json()).then(d => { setCity(String(d.delivery_cities || '').split(',')[0]?.trim() || ''); setShipping(Number(d.shipping_cents) || 0); }).catch(() => {}); }, []);
  const sub = items.reduce((s, i) => s + i.price * i.qty, 0);
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setErr('');
    const f = Object.fromEntries(new FormData(e.currentTarget)) as Record<string, string>;
    const res = await fetch('/api/checkout', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...f, items: items.map(i => ({ productId: i.productId, size: i.size, qty: i.qty })) }) });
    const d = await res.json().catch(() => ({}));
    if (!res.ok) { setErr(d.error || 'Não foi possível finalizar o pedido.'); setBusy(false); return; }
    try { sessionStorage.setItem(`nexowear_wa_${d.code}`, d.whatsappUrl); } catch {}
    writeCart([]); r.push(`/pagamento/${d.code}`);
  }
  if (ready && !items.length) return <p className="wrap sec sold">Seu carrinho está vazio.</p>;
  return (<section className="sec"><div className="wrap" style={{ maxWidth: 640 }}><h2>Finalizar pedido</h2>
    <form onSubmit={submit} style={{ display: 'grid', gap: 12, margin: '24px 0' }}>
      <input style={F} name="name" placeholder="Nome completo" required autoComplete="name" />
      <input style={F} name="phone" placeholder="Telefone/WhatsApp" required inputMode="tel" autoComplete="tel" />
      <input style={F} name="street" placeholder="Endereço" required />
      <input style={F} name="number" placeholder="Número" required />
      <input style={F} name="district" placeholder="Bairro" required />
      <input style={F} name="complement" placeholder="Complemento (opcional)" />
      <input style={F} name="city" placeholder="Cidade" required value={city} onChange={e => setCity(e.target.value)} />
      <p>Subtotal: <strong>{brl(sub)}</strong> · Entrega: <strong>{shipping == null ? '—' : brl(shipping)}</strong> · Total: <strong>{shipping == null ? '—' : brl(sub + shipping)}</strong></p>
      <p className="sold">Ao continuar, você será levado ao WhatsApp da loja com o resumo do pedido para combinar o pagamento.</p>
      {err && <p role="alert" style={{ border: '1px solid #fff', padding: 12 }}>{err}</p>}
      <button className="btn" disabled={busy || !ready}>{busy ? 'Enviando…' : 'Enviar pedido pelo WhatsApp'}</button></form></div></section>);
}
