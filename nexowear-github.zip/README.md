# NexoWear - loja virtual

Next.js + PostgreSQL (Supabase). O pedido é finalizado pelo WhatsApp da loja: o cliente monta o carrinho, preenche os dados, e o site abre o WhatsApp com o resumo (produtos, tamanhos, preços, entrega, total e endereço). O pagamento (PIX) é combinado na conversa.

## Como funciona uma venda
1. O cliente finaliza e cai no WhatsApp da loja com a mensagem pronta. O pedido fica em "Aguardando pagamento" e o estoque fica reservado.
2. Você manda a chave PIX e recebe o pagamento.
3. Em Admin > Pedidos, mude o status: Pagamento aprovado > Em preparação > Saiu para entrega > Entregue. Ao lado de cada pedido há "Chamar no WhatsApp".
4. Pedido sem pagamento por 48 horas é cancelado sozinho e o estoque volta. Você também pode cancelar manualmente.
5. Pedido pago e cancelado (cliente desistiu): devolva o valor e cancele no admin; o estoque volta.

## 1. Rodar localmente
Node 20+. `npm install`, copie `.env.example` para `.env.local`, preencha, `npm run db:init`, `npm run admin:create -- seu@email.com 'SenhaForte123'` (10+ caracteres) e `npm run dev`. Antes de publicar: `npm run build`.

## 2. Banco e imagens (Supabase)
Crie um projeto em supabase.com e copie a connection string (modo pooler) para `DATABASE_URL`. Para fotos, crie um bucket **público** `products` e preencha `SUPABASE_URL` e `SUPABASE_SERVICE_KEY`.

## 3. Primeiro acesso ao admin
Endereço: `seusite/admin/login`. Em Configurações preencha **WhatsApp (obrigatório: sem ele o cliente não consegue finalizar)**, Instagram, cidades atendidas (separadas por vírgula), taxa de entrega em centavos (800 = R$ 8,00) e prazo. Depois apague os 4 produtos de demonstração e cadastre os reais (tamanhos no formato `PP:2,P:5,M:8`).

## 4. Publicar (Firebase App Hosting)
O Firebase Hosting comum não roda a parte de servidor. Use App Hosting (exige plano Blaze, com cota mensal sem custo; crie um alerta de orçamento).
1. Envie o projeto para um repositório no GitHub (sem arquivos `.env`).
2. No Firebase, crie o projeto, ative o Blaze e conecte o repositório em App Hosting.
3. Segredos: `firebase apphosting:secrets:set DATABASE_URL` (idem `ADMIN_SESSION_SECRET` e `SUPABASE_SERVICE_KEY`). Ajuste `APP_URL` e `SUPABASE_URL` no `apphosting.yaml`.
4. Cada push na branch principal publica uma nova versão.

## 5. Domínio
Firebase > App Hosting > Domínios > Adicionar domínio, siga os registros DNS e depois atualize `APP_URL`.

## 6. Testar um pedido
Com o site no ar e o WhatsApp configurado, adicione uma camiseta ao carrinho, finalize e confira se o WhatsApp abre com o resumo e se o pedido aparece em Admin > Pedidos. Use seu próprio número no início.
