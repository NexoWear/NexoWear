'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { addToCart } from '@/lib/cart';
type S = { size: string; stock: number };
export default function AddToCart({ p, sizes }: { p: { id: number; slug: string; name: string; price: number }; sizes: S[] }) {
  const [size, setSize] = useState(''); const [qty, setQty] = useState(1); const [msg, setMsg] = useState(''); const r = useRouter();
  const max = sizes.find(s => s.size === size)?.stock ?? 1;
  function add(go: boolean) {
    if (!size) return setMsg('Escolha um tamanho.');
    addToCart({ slug: p.slug, productId: p.id, name: p.name, size, qty, price: p.price });
    if (go) r.push('/carrinho'); else setMsg('Produto adicionado ao carrinho.');
  }
  return (<div>
    <div role="radiogroup" aria-label="Tamanho" style={{ display: 'flex', gap: 8, flexWrap: 'wrap', margin: '20px 0' }}>
      {sizes.map(s => <button key={s.size} disabled={s.stock < 1} aria-pressed={size === s.size} onClick={() => { setSize(s.size); setQty(1); setMsg(''); }}
        style={{ minWidth: 52, padding: '12px 14px', border: '1px solid #666', background: size === s.size ? '#fff' : '#000', color: size === s.size ? '#000' : s.stock < 1 ? '#555' : '#fff',
          textDecoration: s.stock < 1 ? 'line-through' : 'none', cursor: s.stock < 1 ? 'not-allowed' : 'pointer', fontWeight: 700 }}>{s.size}</button>)}
    </div>
    <label>Quantidade <input type="number" min={1} max={max} value={qty} onChange={e => setQty(Math.max(1, Math.min(max, +e.target.value || 1)))}
      style={{ width: 70, padding: 10, background: '#000', color: '#fff', border: '1px solid #666', marginLeft: 8 }} /></label>
    <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginTop: 20 }}>
      <button className="btn" onClick={() => add(false)}>Adicionar ao carrinho</button>
      <button className="btn" style={{ background: '#000', color: '#fff' }} onClick={() => add(true)}>Comprar agora</button></div>
    <p role="status" className="sold" style={{ marginTop: 12 }}>{msg}</p></div>);
}
