'use client';
import { useState } from 'react';
const F = { background: '#000', color: '#fff', border: '1px solid #666', padding: 12, width: '100%', fontSize: 15 } as const;
export default function ReviewForm({ productId }: { productId: number }) {
  const [rating, setRating] = useState(5); const [msg, setMsg] = useState('');
  async function send(e: React.FormEvent<HTMLFormElement>) { e.preventDefault(); const f = Object.fromEntries(new FormData(e.currentTarget));
    const r = await fetch('/api/reviews', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...f, rating, productId }) });
    const d = await r.json(); setMsg(r.ok ? 'Avaliação enviada. Ela aparece após aprovação da loja.' : d.error); }
  return (<form onSubmit={send} style={{ display: 'grid', gap: 10, maxWidth: 480, marginTop: 16 }}><h3>Avaliar este produto</h3>
    <input style={F} name="orderCode" placeholder="Número do pedido entregue (ex.: NXW-A1B2C3D4E5)" required />
    <select style={F} value={rating} onChange={e => setRating(+e.target.value)} aria-label="Nota">{[5, 4, 3, 2, 1].map(n => <option key={n} value={n}>{'★'.repeat(n)}</option>)}</select>
    <textarea style={F} name="comment" rows={3} placeholder="Comentário" /><button className="btn">Enviar avaliação</button><p role="status" className="sold">{msg}</p></form>);
}
