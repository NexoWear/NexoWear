'use client';
import { useState } from 'react';
import { toggleFav, useFavs } from '@/lib/favorites';
export default function FavButton({ slug, className }: { slug: string; className?: string }) {
  const on = useFavs().includes(slug); const [m, setM] = useState('');
  return (<><button className={className} aria-pressed={on} aria-label={on ? 'Remover dos favoritos' : 'Adicionar aos favoritos'}
    onClick={() => setM(toggleFav(slug) ? 'Adicionado aos favoritos.' : 'Removido dos favoritos.')}
    style={{ background: '#000a', color: '#fff', border: '1px solid #666', width: 42, height: 42, fontSize: 20, cursor: 'pointer' }}>{on ? '♥' : '♡'}</button><span role="status" style={{ position: 'absolute', left: -9999 }}>{m}</span></>);
}
