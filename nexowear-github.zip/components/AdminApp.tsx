'use client';
import { useCallback, useEffect, useState } from 'react';
import { brl } from '@/lib/format';
/* eslint-disable @typescript-eslint/no-explicit-any */
const F = { background: '#000', color: '#fff', border: '1px solid #666', padding: 10, width: '100%', fontSize: 15 } as const;
const ST = ['AGUARDANDO_PAGAMENTO', 'PAGAMENTO_APROVADO', 'EM_PREPARACAO', 'SAIU_PARA_ENTREGA', 'ENTREGUE', 'CANCELADO'];
const api = async (url: string, method = 'GET', body?: unknown) => { const r = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
  const d = await r.json().catch(() => ({})); if (!r.ok) throw new Error(d.error || 'Erro'); return d; };
const wa = (p: string) => { const d = String(p).replace(/\D/g, ''); return `https://wa.me/${d.length <= 11 ? '55' + d : d}`; };
const empty = { name: '', description: '', price: '', promo: '', featured: false, is_launch: false, active: true, images: '', sizes: 'PP:0,P:0,M:0,G:0,GG:0,XG:0' };
export default function AdminApp() {
  const [tab, setTab] = useState('Dashboard'); const [msg, setMsg] = useState('');
  const [stats, setStats] = useState<any>(null); const [prods, setProds] = useState<any[]>([]); const [orders, setOrders] = useState<any[]>([]);
  const [revs, setRevs] = useState<any[]>([]); const [cfg, setCfg] = useState<Record<string, string>>({}); const [form, setForm] = useState<any>(null);
  const load = useCallback(async () => { try { const [s, p, o, c, rv] = await Promise.all([api('/api/admin/stats'), api('/api/admin/products'), api('/api/admin/orders'), api('/api/admin/settings'), api('/api/admin/reviews')]); setRevs(rv); setStats(s); setProds(p); setOrders(o); setCfg(c); } catch (e) { setMsg((e as Error).message); } }, []);
  useEffect(() => { load(); }, [load]);
  const run = async (fn: () => Promise<unknown>, ok: string) => { try { await fn(); setMsg(ok); await load(); } catch (e) { setMsg((e as Error).message); } };
  const edit = (p: any) => setForm({ ...p, price: p.price_cents / 100, promo: p.promo_price_cents != null ? p.promo_price_cents / 100 : '', images: p.images.join('\n'), sizes: p.sizes.map((s: any) => `${s.size}:${s.stock}`).join(',') });
  const save = () => run(async () => { await api('/api/admin/products', 'POST', { ...form,
    images: String(form.images).split('\n').map((x: string) => x.trim()).filter(Boolean),
    sizes: String(form.sizes).split(',').map((x: string) => { const [size, stock] = x.split(':'); return { size, stock: +stock || 0 }; }) }); setForm(null); }, 'Produto salvo.');
  const logout = async () => { await api('/api/admin/logout', 'POST'); location.href = '/admin/login'; };
  return (<section className="sec"><div className="wrap">
    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 24 }}>
      {['Dashboard', 'Produtos', 'Pedidos', 'Avaliações', 'Configurações'].map(t => <button key={t} className="btn" aria-pressed={tab === t} style={tab === t ? {} : { background: '#000', color: '#fff' }} onClick={() => setTab(t)}>{t}</button>)}
      <button className="btn" style={{ background: '#000', color: '#9a9a9a', marginLeft: 'auto' }} onClick={logout}>Sair</button></div>
    {msg && <p role="status" style={{ border: '1px solid #666', padding: 12, marginBottom: 16 }}>{msg}</p>}
    {tab === 'Dashboard' && (stats ? <div><div style={{ display: 'grid', gap: 12, gridTemplateColumns: 'repeat(auto-fit,minmax(150px,1fr))' }}>
      {[['Faturamento', brl(stats.revenue)], ['Vendas pagas', stats.sales], ['Pedidos', stats.orders], ['Produtos', stats.products], ['Peças em estoque', stats.stock]].map(([k, v]) => <div key={k as string} style={{ border: '1px solid #2a2a2a', padding: 16 }}><div className="sold">{k}</div><strong style={{ fontSize: 24 }}>{v}</strong></div>)}</div>
      <h3 style={{ margin: '32px 0 8px' }}>Pedidos por status</h3>{stats.byStatus.map((s: any) => <p key={s.status}>{s.status.replaceAll('_', ' ')}: {s.n}</p>)}
      <h3 style={{ margin: '32px 0 8px' }}>Mais vendidos</h3>{stats.top.length ? stats.top.map((t: any) => <p key={t.name}>{t.name}: {t.qty}</p>) : <p className="sold">Sem vendas ainda.</p>}
      <h3 style={{ margin: '32px 0 8px' }}>Estoque baixo</h3>{stats.low.length ? stats.low.map((l: any, k: number) => <p key={k}>{l.name} ({l.size}): {l.stock}</p>) : <p className="sold">Nenhum.</p>}</div> : <p className="sold">Carregando…</p>)}
    {tab === 'Produtos' && (form ? <div style={{ display: 'grid', gap: 10, maxWidth: 560 }}>
      <input style={F} placeholder="Nome" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
      <textarea style={F} rows={3} placeholder="Descrição" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
      <input style={F} placeholder="Preço (ex.: 89.90)" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} />
      <input style={F} placeholder="Preço promocional (opcional)" value={form.promo} onChange={e => setForm({ ...form, promo: e.target.value })} />
      <label className="sold">Tamanhos e estoque (formato PP:2,P:5,M:8)</label><input style={F} value={form.sizes} onChange={e => setForm({ ...form, sizes: e.target.value })} />
      <label className="sold">Links das imagens (um por linha)</label><textarea style={F} rows={3} value={form.images} onChange={e => setForm({ ...form, images: e.target.value })} />
      <input type="file" accept="image/jpeg,image/png,image/webp" aria-label="Enviar imagem" onChange={async e => { const f = e.target.files?.[0]; if (!f) return; const fd = new FormData(); fd.append('file', f);
        const r = await fetch('/api/admin/upload', { method: 'POST', body: fd }); const d = await r.json(); if (r.ok) { setForm({ ...form, images: (form.images ? form.images + '\n' : '') + d.url }); setMsg('Imagem enviada.'); } else setMsg(d.error); }} />
      {[['featured', 'Destaque'], ['is_launch', 'Lançamento'], ['active', 'Ativo']].map(([k, l]) => <label key={k}><input type="checkbox" checked={!!form[k]} onChange={e => setForm({ ...form, [k]: e.target.checked })} /> {l}</label>)}
      <div style={{ display: 'flex', gap: 8 }}><button className="btn" onClick={save}>Salvar produto</button><button className="btn" style={{ background: '#000', color: '#fff' }} onClick={() => setForm(null)}>Cancelar</button></div></div>
      : <div><button className="btn" onClick={() => setForm(empty)}>Novo produto</button>
        {prods.map(p => <div key={p.id} style={{ display: 'flex', flexWrap: 'wrap', gap: 12, justifyContent: 'space-between', padding: '14px 0', borderBottom: '1px solid #2a2a2a' }}>
          <div><strong>{p.name}</strong> {!p.active && <span className="sold">(inativo)</span>}<div className="sold">{brl(p.price_cents)} · {p.sizes.map((s: any) => `${s.size}:${s.stock}`).join('  ')}</div></div>
          <div style={{ display: 'flex', gap: 8 }}><button className="btn" style={{ padding: '8px 16px' }} onClick={() => edit(p)}>Editar</button>
            <button className="btn" style={{ padding: '8px 16px', background: '#000', color: '#fff' }} onClick={() => confirm('Excluir este produto?') && run(() => api(`/api/admin/products?id=${p.id}`, 'DELETE'), 'Produto removido.')}>Excluir</button></div></div>)}</div>)}
    {tab === 'Pedidos' && (orders.length ? orders.map(o => <div key={o.id} style={{ padding: '16px 0', borderBottom: '1px solid #2a2a2a' }}>
      <strong>{o.code}</strong> · {brl(o.total_cents)} · {o.customer_name} · {o.phone} · <a href={wa(o.phone)} target="_blank" rel="noreferrer" style={{ textDecoration: 'underline' }}>Chamar no WhatsApp</a>
      <div className="sold">{o.street}, {o.number} - {o.district}{o.complement ? ` (${o.complement})` : ''}, {o.city}</div>
      <div className="sold">{o.items.map((i: any) => `${i.qty}x ${i.name} ${i.size}`).join(' | ')}</div>
      <select style={{ ...F, width: 'auto', marginTop: 8 }} value={o.status} onChange={e => { const st = e.target.value; const paid = st === 'CANCELADO' && !['AGUARDANDO_PAGAMENTO', 'CANCELADO'].includes(o.status);
        if (paid && !confirm('Este pedido já foi pago. Cancele só depois de devolver o valor ao cliente. O estoque voltará para a loja. Confirmar cancelamento?')) return;
        run(() => api('/api/admin/orders', 'PATCH', { id: o.id, status: st, confirmRefund: paid || undefined }), 'Status atualizado.'); }}>{ST.map(s => <option key={s} value={s}>{s.replaceAll('_', ' ')}</option>)}</select></div>) : <p className="sold">Nenhum pedido ainda.</p>)}
    {tab === 'Avaliações' && (revs.length ? revs.map(r => <div key={r.id} style={{ padding: '14px 0', borderBottom: '1px solid #2a2a2a' }}>
      <strong>{r.product}</strong> · {'★'.repeat(r.rating)} · {r.author} · <span className="sold">{r.status}</span><p className="sold">{r.comment}</p>
      <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>{[['approved', 'Aprovar'], ['hidden', 'Ocultar']].map(([st, l]) => <button key={st} className="btn" style={{ padding: '8px 16px' }} onClick={() => run(() => api('/api/admin/reviews', 'PATCH', { id: r.id, status: st }), 'Avaliação atualizada.')}>{l}</button>)}
        <button className="btn" style={{ padding: '8px 16px', background: '#000', color: '#fff' }} onClick={() => confirm('Excluir avaliação?') && run(() => api(`/api/admin/reviews?id=${r.id}`, 'DELETE'), 'Avaliação excluída.')}>Excluir</button></div></div>) : <p className="sold">Nenhuma avaliação ainda.</p>)}
    {tab === 'Configurações' && <div style={{ display: 'grid', gap: 10, maxWidth: 560 }}>
      {[['store_name', 'Nome da loja'], ['phone', 'Telefone'], ['whatsapp', 'WhatsApp (só números, com DDI. Ex.: 5598...)'], ['instagram', 'Instagram (@usuario)'], ['delivery_cities', 'Cidades atendidas (separe por vírgula)'], ['shipping_cents', 'Taxa de entrega em centavos (ex.: 800 = R$ 8,00)'], ['delivery_eta', 'Prazo de entrega'], ['launch_at', 'Lançamento (data e hora)']].map(([k, l]) =>
        <label key={k}><span className="sold">{l}</span><input style={F} type={k === 'launch_at' ? 'datetime-local' : 'text'} value={cfg[k] ?? ''} onChange={e => setCfg({ ...cfg, [k]: e.target.value })} /></label>)}
      <label><span className="sold">Texto "Sobre nós"</span><textarea style={F} rows={6} value={cfg.about_text ?? ''} onChange={e => setCfg({ ...cfg, about_text: e.target.value })} /></label>
      <button className="btn" onClick={() => run(() => api('/api/admin/settings', 'PUT', cfg), 'Configurações salvas.')}>Salvar configurações</button></div>}
  </div></section>);
}
