'use client';
import { useEffect, useState } from 'react';
export default function Countdown({ at }: { at: string }) {
  const t = new Date(at).getTime(); const [now, setNow] = useState<number | null>(null);
  useEffect(() => { setNow(Date.now()); const i = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(i); }, []);
  if (now === null || isNaN(t) || t <= now) return null;
  const s = Math.floor((t - now) / 1000); const u = [['dias', Math.floor(s / 86400)], ['horas', Math.floor(s / 3600) % 24], ['minutos', Math.floor(s / 60) % 60], ['segundos', s % 60]];
  return (<section className="sec" style={{ borderBottom: '1px solid #2a2a2a' }}><div className="wrap"><h2>Novo drop</h2>
    <div style={{ display: 'flex', gap: 'clamp(12px,4vw,40px)', marginTop: 16 }} role="timer">{u.map(([l, v]) => <div key={l as string}><div style={{ fontSize: 'clamp(2rem,9vw,5rem)', fontWeight: 800 }}>{String(v).padStart(2, '0')}</div><div className="sold">{l}</div></div>)}</div></div></section>);
}
