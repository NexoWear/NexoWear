'use client';
import Link from 'next/link';
import Image from 'next/image';
import { useState } from 'react';
import { useCart } from '@/lib/cart';
import { useFavs } from '@/lib/favorites';

export default function Header() {
  const [open, setOpen] = useState(false);
  const { items } = useCart();
  const favs = useFavs();
  const close = () => setOpen(false);
  return (
    <header className="hdr">
      <div className="wrap hdr-inner">
        <button className="menu-btn" aria-label={open ? 'Fechar menu' : 'Abrir menu'} aria-expanded={open} onClick={() => setOpen(v => !v)}>
          <span /><span /><span />
        </button>
        <Link href="/" aria-label="NexoWear - início" onClick={close} className="brand">
          <Image src="/logo.png" alt="NexoWear" width={180} height={180} priority />
        </Link>
        <nav className={`nav main-nav ${open ? 'mobile-open' : ''}`} aria-label="Principal">
          <Link href="/" onClick={close}>Início</Link>
          <Link href="/loja" onClick={close}>Loja</Link>
          <Link href="/sobre" onClick={close}>Sobre nós</Link>
          <Link href="/contato" onClick={close}>Contato</Link>
          <Link href="/pedido" onClick={close}>Acompanhar pedido</Link>
        </nav>
        <nav className="nav actions-nav" aria-label="Ações">
          <Link href="/favoritos" aria-label={`Favoritos${favs.length ? `, ${favs.length}` : ''}`}>♡<span className="desktop-label"> Favoritos</span>{favs.length > 0 && <b className="badge">{favs.length}</b>}</Link>
          <Link href="/carrinho" aria-label={`Carrinho${items.length ? `, ${items.length} itens` : ''}`}>🛒<span className="desktop-label"> Carrinho</span>{items.length > 0 && <b className="badge">{items.length}</b>}</Link>
        </nav>
      </div>
    </header>
  );
}
