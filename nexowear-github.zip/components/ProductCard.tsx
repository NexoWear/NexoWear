import Link from 'next/link';
import { Product, brl } from '@/lib/db';
import FavButton from './FavButton';
export default function ProductCard({ p }: { p: Product }) {
  const promo = p.promo_price_cents != null && p.promo_price_cents < p.price_cents;
  return (<article className="card" style={{ position: 'relative' }}>
    <div style={{ position: 'absolute', top: 8, right: 8, zIndex: 2 }}><FavButton slug={p.slug} /></div>
    <Link href={`/produto/${p.slug}`}>
      <div className="ph">{p.image ? <img src={p.image} alt={p.name} loading="lazy" /> : <span>Imagem do produto (placeholder)</span>}</div>
      <h3>{p.name}</h3>
      <div className="pr">{promo && <s>{brl(p.price_cents)}</s>}{brl(promo ? p.promo_price_cents! : p.price_cents)}</div>
      <div className="sold">{p.rating != null ? `★ ${p.rating}` : 'Sem avaliações'} · {p.in_stock ? 'Disponível' : 'Esgotado'}</div>
    </Link></article>);
}
