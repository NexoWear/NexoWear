import { brl } from './format';
export type OrderMsg = { code: string; name: string; phone: string; street: string; number: string; district: string; complement?: string | null; city: string;
  subtotal: number; shipping: number; total: number; lines: { name: string; size: string; qty: number; price: number }[] };
// Aceita números com ou sem DDI; se vier só com DDD (10 ou 11 dígitos), assume Brasil (55).
export function waNumber(raw: string) { const d = (raw || '').replace(/\D/g, ''); return !d ? '' : d.length <= 11 ? `55${d}` : d; }
export function whatsappUrl(number: string, o: OrderMsg) {
  const msg = [`Olá, NexoWear! Quero finalizar meu pedido *${o.code}*:`, '',
    ...o.lines.map(l => `• ${l.qty}x ${l.name} (${l.size}) - ${brl(l.price)} cada = ${brl(l.price * l.qty)}`), '',
    `Subtotal: ${brl(o.subtotal)}`, `Entrega: ${brl(o.shipping)}`, `*Total: ${brl(o.total)}*`, '',
    `Nome: ${o.name}`, `Telefone: ${o.phone}`,
    `Endereço: ${o.street}, ${o.number} - ${o.district}${o.complement ? ` (${o.complement})` : ''}, ${o.city}`, '',
    'Pode me enviar a chave PIX para o pagamento?'].join('\n');
  return `https://wa.me/${number}?text=${encodeURIComponent(msg)}`;
}
