'use client';
import { useEffect, useState } from 'react';
const KEY = 'nexowear_favs';
const read = (): string[] => { try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch { return []; } };
export function toggleFav(slug: string) { const f = read(); const n = f.includes(slug) ? f.filter(x => x !== slug) : [...f, slug]; localStorage.setItem(KEY, JSON.stringify(n)); window.dispatchEvent(new Event('favs')); return !f.includes(slug); }
export function useFavs() { const [f, set] = useState<string[]>([]); useEffect(() => { const s = () => set(read()); s(); window.addEventListener('favs', s); return () => window.removeEventListener('favs', s); }, []); return f; }
