import { Pool } from 'pg';
const g = globalThis as unknown as { pool?: Pool };
export const pool = g.pool ?? new Pool({ connectionString: process.env.DATABASE_URL, max: 5,
  ssl: process.env.DATABASE_URL?.includes('localhost') ? false : { rejectUnauthorized: false } });
if (process.env.NODE_ENV !== 'production') g.pool = pool;
export type Product = { id: number; slug: string; name: string; price_cents: number; promo_price_cents: number | null;
  image: string | null; in_stock: boolean; rating: number | null };
export type Filters = { q?: string; featured?: boolean; size?: string; inStock?: boolean; maxPrice?: number; minRating?: number; sort?: string };
export async function listProducts(o: Filters = {}): Promise<Product[]> {
  const w = ['p.active']; const v: unknown[] = [];
  const add = (sql: string, val: unknown) => { v.push(val); w.push(sql.replace('?', `$${v.length}`)); };
  if (o.featured) w.push('p.featured');
  if (o.q) add(`p.name ILIKE '%'||?||'%'`, o.q);
  if (o.size) add('EXISTS (SELECT 1 FROM product_sizes s WHERE s.product_id=p.id AND s.size=? AND s.stock>0)', o.size);
  if (o.inStock) w.push('EXISTS (SELECT 1 FROM product_sizes s WHERE s.product_id=p.id AND s.stock>0)');
  if (o.maxPrice) add('COALESCE(p.promo_price_cents,p.price_cents) <= ?', o.maxPrice);
  if (o.minRating) add(`(SELECT AVG(rating) FROM reviews r WHERE r.product_id=p.id AND r.status='approved') >= ?`, o.minRating);
  const order = o.sort === 'vendidos' ? 'p.sold_count DESC, p.created_at DESC' : o.sort === 'avaliacao' ? 'rating DESC NULLS LAST' : o.sort === 'menor' ? 'COALESCE(p.promo_price_cents,p.price_cents) ASC' : 'p.created_at DESC';
  const { rows } = await pool.query(
    `SELECT p.id,p.slug,p.name,p.price_cents,p.promo_price_cents,
      (SELECT url FROM product_images i WHERE i.product_id=p.id ORDER BY position LIMIT 1) AS image,
      COALESCE((SELECT SUM(stock) FROM product_sizes s WHERE s.product_id=p.id),0) > 0 AS in_stock,
      (SELECT ROUND(AVG(rating),1)::float FROM reviews r WHERE r.product_id=p.id AND r.status='approved') AS rating
     FROM products p WHERE ${w.join(' AND ')} ORDER BY ${order}`, v);
  return rows;
}
export { brl } from './format';
