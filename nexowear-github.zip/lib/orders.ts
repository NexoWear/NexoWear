import { pool } from './db';

export async function cancelAndRestock(orderId: number) {
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    const { rows: [o] } = await c.query(
      `UPDATE orders SET status='CANCELADO', payment_status='cancelled'
       WHERE id=$1 AND status='AGUARDANDO_PAGAMENTO'
       RETURNING id`, [orderId]);
    if (!o) {
      await c.query('ROLLBACK');
      return false;
    }
    await c.query(
      `UPDATE product_sizes s SET stock=s.stock+i.quantity
       FROM order_items i
       WHERE i.order_id=$1 AND s.product_id=i.product_id AND s.size=i.size`, [orderId]);
    await c.query('COMMIT');
    return true;
  } catch (e) {
    await c.query('ROLLBACK');
    throw e;
  } finally {
    c.release();
  }
}

// Cancela um pedido já pago e ainda não despachado. Só deve ser chamado depois que o admin confirmou a devolução do valor ao cliente.
export async function cancelPaidAndRestock(orderId: number) {
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    const { rows: [o] } = await c.query(
      `UPDATE orders SET status='CANCELADO', payment_status='refunded'
       WHERE id=$1 AND status IN ('PAGAMENTO_APROVADO','EM_PREPARACAO')
       RETURNING id`, [orderId]);
    if (!o) { await c.query('ROLLBACK'); return false; }
    await c.query(
      `UPDATE product_sizes s SET stock=s.stock+i.quantity
       FROM order_items i WHERE i.order_id=$1 AND s.product_id=i.product_id AND s.size=i.size`, [orderId]);
    await c.query(
      `UPDATE products p SET sold_count=GREATEST(0,p.sold_count-i.q)
       FROM (SELECT product_id,SUM(quantity)::int AS q FROM order_items WHERE order_id=$1 GROUP BY 1) i WHERE p.id=i.product_id`, [orderId]);
    await c.query('COMMIT'); return true;
  } catch (e) { await c.query('ROLLBACK'); throw e; } finally { c.release(); }
}

// Pedidos sem confirmação de pagamento por muito tempo liberam o estoque reservado.
export async function expireStaleOrders(hours = 48) {
  const { rows } = await pool.query(`SELECT id FROM orders WHERE status='AGUARDANDO_PAGAMENTO' AND created_at < now() - make_interval(hours => $1)`, [hours]);
  for (const r of rows) await cancelAndRestock(r.id);
}
