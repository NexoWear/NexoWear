import { pool } from './db';
export async function getSettings(): Promise<Record<string, string>> {
  const { rows } = await pool.query('SELECT key,value FROM settings');
  return Object.fromEntries(rows.map(r => [r.key, r.value]));
}
