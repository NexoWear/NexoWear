'use client';
import { useEffect, useState } from 'react';
export type CartItem = { slug: string; productId: number; name: string; size: string; qty: number; price: number };
const KEY = 'nexowear_cart';
export function readCart(): CartItem[] { try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch { return []; } }
export function writeCart(items: CartItem[]) { localStorage.setItem(KEY, JSON.stringify(items)); window.dispatchEvent(new Event('cart')); }
export function addToCart(i: CartItem) {
  const c = readCart(); const f = c.find(x => x.productId === i.productId && x.size === i.size);
  if (f) f.qty += i.qty; else c.push(i); writeCart(c);
}
export function useCart() {
  const [items, set] = useState<CartItem[]>([]); const [ready, setReady] = useState(false);
  useEffect(() => { const s = () => { set(readCart()); setReady(true); }; s(); window.addEventListener('cart', s); return () => window.removeEventListener('cart', s); }, []);
  return { items, ready };
}
