import { createHmac, timingSafeEqual, scryptSync, randomBytes } from 'crypto';
import { cookies } from 'next/headers';
// O Firebase só repassa ao servidor o cookie chamado "__session".
const COOKIE = '__session';
const secret = () => { const s = process.env.ADMIN_SESSION_SECRET; if (!s || s.length < 32) throw new Error('Defina ADMIN_SESSION_SECRET com 32+ caracteres'); return s; };
const sign = (v: string) => createHmac('sha256', secret()).update(v).digest('hex');
export function hashPassword(p: string) { const salt = randomBytes(16).toString('hex'); return `${salt}:${scryptSync(p, salt, 64).toString('hex')}`; }
export function checkPassword(p: string, h: string) { const [salt, hex] = h.split(':'); const a = Buffer.from(hex, 'hex'); const b = scryptSync(p, salt, 64); return a.length === b.length && timingSafeEqual(a, b); }
export async function startSession(id: number) {
  const v = `${id}.${Date.now() + 7 * 864e5}`;
  (await cookies()).set(COOKIE, `${v}.${sign(v)}`, { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'strict', path: '/', maxAge: 7 * 86400 });
}
export async function endSession() { (await cookies()).delete(COOKIE); }
export async function isAdmin() {
  try {
    const c = (await cookies()).get(COOKIE)?.value; if (!c) return false;
    const i = c.lastIndexOf('.'); const v = c.slice(0, i), s = c.slice(i + 1), e = sign(v);
    if (s.length !== e.length || !timingSafeEqual(Buffer.from(s), Buffer.from(e))) return false;
    return Number(v.split('.')[1]) > Date.now();
  } catch { return false; }
}
export async function requireAdmin(): Promise<Response | null> { return (await isAdmin()) ? null : Response.json({ error: 'Não autorizado.' }, { status: 401 }); }
