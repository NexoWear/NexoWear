// Uso: DATABASE_URL=... node scripts/create-admin.mjs email@loja.com 'SenhaForte123'
import pg from 'pg'; import { scryptSync, randomBytes } from 'crypto';
const [email, pass] = process.argv.slice(2);
if (!email || !pass || pass.length < 10) { console.error('Informe e-mail e senha (mínimo 10 caracteres).'); process.exit(1); }
const salt = randomBytes(16).toString('hex'); const hash = `${salt}:${scryptSync(pass, salt, 64).toString('hex')}`;
const c = new pg.Client({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_URL?.includes('localhost') ? false : { rejectUnauthorized: false } });
await c.connect(); await c.query('INSERT INTO admins(email,password_hash) VALUES($1,$2) ON CONFLICT (email) DO UPDATE SET password_hash=$2', [email.toLowerCase(), hash]); await c.end(); console.log('Administrador salvo.');
